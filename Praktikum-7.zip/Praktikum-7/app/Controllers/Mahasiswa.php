<?php

namespace App\Controllers;

use App\Models\MahasiswaModel;

class Mahasiswa extends BaseController
{
    public function index(){
        //objek model mahasiswa
        $this->mhs1 = new MahasiswaModel();
        $this->mhs2 = new MahasiswaModel();
        $this->mhs3 = new MahasiswaModel();

        //memberi nilai pada objek
        $this->mhs1->id = 1;
        $this->mhs1->nama = "Ilham Panca Pamungkas";
        $this->mhs1->nim = "21143";
        $this->mhs1->gender = "L";
        $this->mhs1->tmp_lahir = "Depok";
        $this->mhs1->tgl_lahir = "26 Maret 2002";
        $this->mhs1->ipk = 3.59;

        $this->mhs2->id = 2;
        $this->mhs2->nama = "Jessica Anggreini";
        $this->mhs2->nim = "21145";
        $this->mhs2->gender = "P";
        $this->mhs2->tmp_lahir = "Bandung";
        $this->mhs2->tgl_lahir = "15 Juni 2003";
        $this->mhs2->ipk = 3.59;

        $this->mhs3->id = 3;
        $this->mhs3->nama = "Mufidah Anjani Zarifah";
        $this->mhs3->nim = "21156";
        $this->mhs3->gender = "P";
        $this->mhs3->tmp_lahir = "Jakarta";
        $this->mhs3->tgl_lahir = "09 Oktober 2002";
        $this->mhs3->ipk = 3.86;

        $list_mhs = [$this->mhs1, $this->mhs2, $this->mhs3];
        $data['list_mhs'] = $list_mhs;

        //return view dan mengirim sebuah data array
        return view('mahasiswa/index', $data);
    }
}